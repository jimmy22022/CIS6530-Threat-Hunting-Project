#!/bin/bash

mkdir processed

for FILE in *.opcode;
do
	cat "$FILE" | cut -d $'\t' -f 3 | cut -d " " -f 1 > "processed/$FILE"
done

