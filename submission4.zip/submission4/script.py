#!/bin/python3

import os, sys, re, json
import pandas as pd

target_labels = [
    "Ke3chang", "menuPass", "Moafee", "Mofang", "Mustang Panda", "Naikon", "Night Dragon", "Operation Wocao", "PittyTiger", 
    "Putter Panda", "Rocke", "Scarlet Mimic", "Suckfly", "GOLD SOUTHFIELD", "Inception", "Indrik Spider", "RTM", "TA505", 
    "Windigo", "Wizard Spider", "APT-C-36", "Darkhotel", "Higaisa", "Evilnum", "FIN10", "FIN6", "FIN8", 
    "APT39", "Cleaver", "CopyKittens", "Fox Kitten", "Group5", "Leafminer", "Magic Hound", "MuddyWater"
]

regex = [
    "^Ke3chang", "^menuPass", "^Moafee", "^Mofang", "^MustangPanda", "^Naikon", "^NightDragon", "^OperationWocao", "^PittyTiger",
    "^PutterPanda", "^Rocke", "^ScarletMimic", "^Suckfly", "^GOLD_SOUTHFIELD", "^Inception", "^IndrikSpider", "^RTM", "^TA505",
    "^Windigo", "^WizardSpider", "^APT-C-36", "^Darkhotel", "^Higaisa", "^Evilnum", "^FIN10", "^FIN6", "^FIN8", 
    "^APT39", "^Cleaver", "^CopyKittens", "^FoxKitten", "^Group5", "^Leafminer", "^MagicHound", "^MuddyWater"
]

data = []

def match_target(filename: str) -> int:
    for (i, r) in enumerate(regex):
        if re.search(r, filename) is not None:
            return i
    return -1

for filename in os.listdir("."):
    t = match_target(filename)
    label = target_labels[t]
    if t == -1:
        print(f"error: {filename}")
        continue
    print(f"{label} : {filename}")
    with open(filename) as file:
        text = []
        for line in file:
            line = line.strip()
            text.append(line)
        data.append([" ".join(text), label])

df = pd.DataFrame(data, columns=["text", "label"])
df.to_csv("data.csv", index=False)

