import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

import tensorflow as tf
from sklearn.utils import compute_class_weight
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense

# 1. Load the data.
data = pd.read_csv("data_3.csv")
data["tokens"] = data["text"].str.split()

# 2. Build the opcode to integer vocabulary.
vocab = {}
for tokens in data["tokens"]:
    for op in tokens:
        if op not in vocab:
            vocab[op] = len(vocab) + 1

# 3. Encode sequences as integer id vectors
sequences = [[vocab[op] for op in tokens] for tokens in data["tokens"]]
MAX_LEN = max(len(seq) for seq in sequences)
X = pad_sequences(
    sequences,
    maxlen=MAX_LEN,
    padding="post",
    truncating="post"
)

# 4. Encode labels as integer classes
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(data["label"].values)
num_classes = len(label_encoder.classes_)

# 5. Split the data into training and testing sets.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.15, random_state=42, stratify=y
)

# 6. Build the CNN model.
vocab_size = len(vocab) + 1  # +1 for padding index 0
embedding_dim = 8            # k in the paper
num_filters = 64             # convo filters in the paper
kernel_size = 8              # filter width (can experiment)
hidden_units = 16            # size of dense hidden layer

model = Sequential(
    [
        Embedding(input_dim=vocab_size, output_dim=embedding_dim, input_length=MAX_LEN),
        Conv1D(filters=num_filters, kernel_size=kernel_size, activation='relu', padding='same'),
        GlobalMaxPooling1D(),
        Dense(hidden_units, activation='relu'),
        Dense(num_classes, activation='softmax')
    ]
)

optimizer = tf.keras.optimizers.RMSprop(learning_rate=1e-2)
model.compile(optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.summary()

# 7. Train the model.

# Class weights for the heavily imbalanced labels
class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train)
class_weight_dict = {i: w for i, w in enumerate(class_weights)}

# Implement early stopping.
early_stop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True,)

history = model.fit(X_train, y_train, epochs=20, batch_size=16, validation_split=0.1, callbacks=[early_stop], class_weight=class_weight_dict, verbose=2)

# 8. Evaluate on test set
test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test loss: {test_loss:.4f}")
print(f"Test accuracy: {test_acc:.4f}")